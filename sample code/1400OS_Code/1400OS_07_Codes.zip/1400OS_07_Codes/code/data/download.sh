#!/usr/bin/env bash
wget http://www.csie.ntu.edu.tw/~cjlin/libsvmtools/datasets/regression/E2006.train.bz2
bunzip2 E2006.train.bz2
wget http://www.grouplens.org/system/files/ml-100k.zip
unzip ml-100k.zip
